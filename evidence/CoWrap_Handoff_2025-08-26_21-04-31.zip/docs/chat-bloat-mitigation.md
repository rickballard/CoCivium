# Chat‑Bloat Mitigation (Operational)
Keep chats responsive and reliable by moving state to durable artifacts.

## Core norms
- **Short turns, long memory in repo.** Store plans/workflows in repo docs; link them in chat rather than re‑pasting.
- **Periodic snapshots.** When a thread grows, export key state into a single page (README section or /docs/*) and restart a fresh chat.
- **Use automation for “check later.”** Create scheduled tasks (e.g., PR monitors) instead of asking chat to remember.
- **Single-source-of-truth.** Backlogs (ACB), runbooks, and guardrails live in the repo so any new session can pick up instantly.
- **Idempotent scripts.** All “CoPing/DO” blocks should be safe to run multiple times (locks, dry-run prompts, preflight).

## Practical tactics
- Keep one chat per **objective**; fork a new chat when the topic changes materially.
- Prefer **links** to repo docs over re‑explaining context.
- Use “handoff‑prompt.txt” when you must start a new tab.
- When CI logs or CLI output are huge, paste only the **tail** + your summary.
