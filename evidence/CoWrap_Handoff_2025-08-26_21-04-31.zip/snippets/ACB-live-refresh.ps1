# Live ACB refresh (PowerShell)
$REPO="rickballard/CoCivium"; $ADV="docs/backlog/ADVANCED.md"
$issues = gh issue list -R $REPO --state open --label "type:task" --label "level:advanced" --json number,title,labels,url,updatedAt | ConvertFrom-Json
function Get-Area($labels){ $a = $labels | ForEach-Object name | Where-Object {$_ -like 'area:*'} | Select-Object -First 1; if($a){ $a.Substring(5) } else { 'general' } }
$lines=@()
if(!$issues){ $lines+="_No labeled Issues matched `type:task + level:advanced` right now._" } else {
  $issues | Group-Object { Get-Area $_.labels } | Sort-Object Name | ForEach-Object {
    $lines+="### $($_.Name)"
    $_.Group | Sort-Object updatedAt -Descending | ForEach-Object {
      $lines+=("- **#{0}** — [{1}]({2}) _(updated {3})_" -f $_.number,$_.title,$_.url,(Get-Date $_.updatedAt).ToString('yyyy-MM-dd'))
    }; $lines+=""
  }
}
$txt = Get-Content -Raw -LiteralPath $ADV
$block = "<!-- LIVE:BEGIN -->`n{0}`n<!-- LIVE:END -->" -f (($lines -join "`n").TrimEnd())
$txt = [regex]::Replace($txt,'<!-- LIVE:BEGIN -->.*?<!-- LIVE:END -->', { param($m) $block }, 'Singleline') -replace "`r`n","`n"
$txt | Set-Content -LiteralPath $ADV -Encoding utf8 -NoNewline
