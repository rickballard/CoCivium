# Tasks & Checklist (running log)

## Done
- Implemented **CoSafety** guardrails (lock, preflight, confirmations, protection backup/restore).
- Added **Show-CoDay** function to auto-open ACB + ISSUEOPS on workbench start.
- Curated and refreshed ACB content; added live Issues feed pattern.
- Salvaged detached work tip (`git branch wip/detached-salvage <sha>`).
- Documented chat‑bloat workaround and handoff process (this bundle).

## In Progress
- PR hygiene and merges (e.g., branches that needed rebase/approvals).
- Converting backlog to structured source (ADVANCED.yaml + renderer).

## Next (Concrete)
- Land `scripts/tools/CoSafety.ps1` in repo (if not merged) and reference it from risky scripts.
- Wire **Show-CoDay.ps1** from the workbench startup path.
- Add CI for nightly README “New” strip / ACB refresh if desired.
- Use `scripts/monitor-prs.ps1` to summarize and unblock priority PRs; paste the JSON summary in Issues/PR threads.
- Fold these patterns into **BPOE/RepoAccelerator/CoAgent Kit** docs folders.
