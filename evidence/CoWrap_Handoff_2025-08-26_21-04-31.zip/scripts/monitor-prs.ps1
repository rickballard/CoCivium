<#
Usage examples:
  pwsh -NoProfile -File scripts/monitor-prs.ps1 -Repo rickballard/CoCivium -Pr 247
  pwsh -NoProfile -File scripts/monitor-prs.ps1 -Repo rickballard/CoCivium -Pr 242,243
Requires: GitHub CLI (`gh`) logged in.
#>
param(
  [Parameter(Mandatory=$true)][string]$Repo,
  [Parameter(Mandatory=$true)][int[]]$Pr
)

function View-Pr($n){
  $json = gh pr view $n -R $Repo --json number,title,state,merged,mergeable,mergeStateStatus,reviewDecision,baseRefName,headRefName,url
  if(-not $json){ return $null }
  return $json | ConvertFrom-Json
}

$reports = @()
foreach($n in $Pr){
  $p = View-Pr $n
  if(-not $p){
    $reports += @{ number=$n; status="not_found"; message="PR #$n not found" }
    continue
  }
  if($p.merged -eq $true){
    $reports += @{ number=$n; status="merged"; url=$p.url; title=$p.title }
    continue
  }
  $next = @()
  if($p.mergeable -eq $false){ $next += "Rebase/resolve conflicts on branch '$($p.headRefName)' against '$($p.baseRefName)'" }
  if($p.reviewDecision -eq "REVIEW_REQUIRED"){ $next += "Request and obtain at least one approving review" }
  if($p.mergeStateStatus -in @("BLOCKED","DIRTY")){ $next += "Check branch protections / required checks; rerun or fix failing CI" }
  if(-not $next){ $next = @("Run `gh pr merge $($p.number) -R $Repo --squash` when ready") }

  $reports += @{
    number=$p.number; status="open"; url=$p.url; title=$p.title;
    mergeable=$p.mergeable; mergeStateStatus=$p.mergeStateStatus; reviewDecision=$p.reviewDecision;
    nextSteps=$next
  }
}

$reports | ConvertTo-Json -Depth 5 | Write-Output
